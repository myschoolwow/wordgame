MySchool WOW 4 — Yerel test sürümü

Bu paket WOW4_v01(1).zip temel alınarak hazırlanmıştır. Puzzle ve tema dosyaları birebir korunmuştur.

Düzeltmeler: WOW4 için bağımsız localStorage anahtarları ve BroadcastChannel, 4. sınıf PWA manifesti, WOW4 service worker önbelleği ve puzzle dışa aktarma dosya adı.

ÖNEMLİ: Eski WOW4 sürümünde wow3_ anahtarlarına kaydedilmiş ilerlemeler otomatik taşınmaz. Bunun nedeni WOW3 ile aynı tarayıcıda kayıtların karışmış olabilmesidir. Orijinal tarayıcı verilerini silmeyin; öğrenci kullanılan ortama bu test paketini henüz kurmayın.

Yerelde test için klasörde `python -m http.server 8000` çalıştırıp http://localhost:8000 adresini açın. ZIP içindeki index.html dosyasını doğrudan açmak PWA özelliklerini doğru test etmez.
